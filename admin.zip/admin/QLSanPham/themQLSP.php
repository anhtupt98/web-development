<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<script>
function ktthemsp()
{
	var dem=0;
	var tensp=document.getElementById("txtTenSP").value;
	var errTenSP=document.getElementById("errTenSP");
	if(tensp.length==0)
	{
		errTenSP.innerHTML=" *Không được để trống";
	}
	else
	{
		errTenSP.innerHTML="";
		dem++;
	}
	var mota=document.getElementById("txtMota").value;
	var errMota=document.getElementById("errMota");
	if(mota.length==0)
	{
		errMota.innerHTML=" *Không được để trống";
	}
	else
	{
		errMota.innerHTML="";
		dem++;
	}
	var gia=document.getElementById("txtGia").value;
	var errGia=document.getElementById("errGia");
	if(gia.length==0)
	{
		errGia.innerHTML=" *Không được để trống";
	}
	else
	{
		errGia.innerHTML="";
		dem++;
	}
	var tinhtrang=document.getElementById("cboTT").value;
	var errTinhTrang=document.getElementById("errTinhTrang");
	if(tinhtrang==0)
	{
		errTinhTrang.innerHTML=" *Phải chọn tình trạng";
	}
	else
	{
		errTinhTrang.innerHTML="";
		dem++;
	}
	if(dem==4)
	{
		return true;
	}
	else
	{
		return false;
	}
}
</script>
<body>
<?php
include("../KetNoi/ketnoi.inc");
$strSelectMaxMa="select max(MaSP) as MaxMa from tblquanlysp";
$resultMaxMa=mysqli_query($con,$strSelectMaxMa);
$rowMaxMa=mysqli_fetch_array($resultMaxMa);
$MaxMa=$rowMaxMa["MaxMa"];
$MaSP=1;
if($MaxMa!="")
{
	$MaSP=$MaxMa+1;
}
?>
<form action="../QLSanPham/themQLSPxuly.php" method="post" enctype="multipart/form-data">
	<table border="1" cellspacing="0" bordercolor="#000000" width="60%" style="position:absolute;top:110px;left:250px">
    	<tr >
            <h1><font color="#666666" size="+5">♛ Thêm Sản Phẩm</font></h1>
        </tr>
    	<tr>
        	<td>Mã sản phẩm</td>
            <td><input type="text" name="txtMaSP" value="<?php echo $MaSP;?>"/></td>
            
        </tr>
        <tr>
        	<td>Tên sản phẩm</td>
            <td><input type="text" name="txtTenSP" id="txtTenSP"/><span id="errTenSP"></span></td>
        </tr>
        <tr>
        	<td>Mô tả</td>
            <td><textarea cols="75" rows="8"  style="overflow:scroll"  name="txtMota" id="txtMota"/></textarea><span id="errMota"></span></td>
        </tr>
        <tr>
        	<td>Ảnh</td>
            <td><input type="file" name="txtAnh" /></td>
            
        </tr>
        <tr>
        	<td>Giá</td>
            <td><input type="text" name="txtGia" id="txtGia"/><span id="errGia"></span></td>
        </tr>
        <tr>
        	<td>Tình trạng</td>
            <td>
            	<select name="cboTT" id="cboTT">
                	<option value="0">--Chọn--</option>
                    <option value="Còn hàng">Còn Hàng</option>
                    <option value="Hết hàng">Hết Hàng</option>
                </select>
                <span id="errTinhTrang"></span>
            </td>
        </tr>
        <tr>
        <?php
			$result=mysqli_query($con,"select * from tblquanlynsx");
		?>
        	<td>Tên nhà sản xuất</td>
           
            <td>
            <select name="txtMaNSX">
            <?php
			while($row=mysqli_fetch_array($result))
			{
			?>
            	<option value="<?php echo $row["MaNSX"];?>"><?php echo $row["TenNSX"];?></option>
            <?php
			}
			?>
            </select>
            </td>
           
        </tr>
        <tr>
        <?php
		$result2=mysqli_query($con,"select * from tblquanlyloaisp");
		?>
        	<td>Tên Loại</td>
            <td>
            <select name="txtMaLoai">
            <?php
			while($row2=mysqli_fetch_array($result2))
			{
			?>
            	<option value="<?php echo $row2["MaLoai"];?>"><?php echo $row2["TenLoai"];?></option>
            <?php
			}
			?>
            </select>
            
            </td>
        </tr>
        <tr>
            <th colspan="2"><input type="submit" value="Thêm Mới" onclick="return ktthemsp()"/></th>
        </tr>
    </table>
</form>
<?php
include("../KetNoi/dongketnoi.inc");
?>
</body>
</html>
