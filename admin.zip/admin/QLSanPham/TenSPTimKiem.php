<?php
include("../KetNoi/ketnoi.inc");
if(isset($_GET['TenSPTimKiem']))
{
	$tensptimkiem=$_GET['TenSPTimKiem'];
	$sql="select tblquanlysp.MaSP,tblquanlysp.TenSP,tblquanlysp.mota,tblquanlysp.anh,tblquanlysp.gia,tblquanlysp.tinhtrang,tblquanlynsx.TenNSX from tblquanlysp inner join tblquanlynsx on tblquanlysp.MaNSX=tblquanlynsx.MaNSX where tblquanlysp.TenSP like '%$tensptimkiem%'";
	$result=mysqli_query($con,$sql);
}
include("../KetNoi/dongketnoi.inc");
header("Location:../login/AdminThuong.php?cat=5&&TenSPTimKiem=$tensptimkiem");
?>