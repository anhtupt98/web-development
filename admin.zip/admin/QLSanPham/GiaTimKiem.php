<?php
include("../KetNoi/ketnoi.inc");
if(isset($_GET['GiaTimKiem']))
{
	$GiaTimKiem=$_GET['GiaTimKiem'];
	$sql="select tblquanlysp.MaSP,tblquanlysp.TenSP,tblquanlysp.mota,tblquanlysp.anh,tblquanlysp.gia,tblquanlysp.tinhtrang,tblquanlynsx.TenNSX from tblquanlysp inner join tblquanlynsx on tblquanlysp.MaNSX=tblquanlynsx.MaNSX where tblquanlysp.gia like '%$GiaTimKiem%'";
	$result=mysqli_query($con,$sql);
}
include("../KetNoi/dongketnoi.inc");
header("Location:../login/AdminThuong.php?cat=5&&GiaTimKiem=$GiaTimKiem");
?>