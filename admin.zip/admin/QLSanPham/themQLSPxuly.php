<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php 
	$MaSP=$_POST["txtMaSP"];
	$TenSP=$_POST["txtTenSP"];
	$Mota=$_POST["txtMota"];
	$Anh=$_FILES["txtAnh"];
	include("UploadAnhXuLy.php");
	$Gia=$_POST["txtGia"];
	$TinhTrang=$_POST["cboTT"];
	$MaNSX=$_POST["txtMaNSX"];
	$MaLoai=$_POST["txtMaLoai"];
	include("../KetNoi/ketnoi.inc");
	$strInsert="insert into tblquanlysp (MaSP,TenSP,mota,anh,gia,MaNSX,tinhtrang,MaLoai) values ('$MaSP','$TenSP','$Mota','$actual_image_name','$Gia','$MaNSX','$TinhTrang','$MaLoai')";
	$result = mysqli_query($con,$strInsert);
	include("../KetNoi/dongketnoi.inc");
	header("Location:../login/AdminThuong.php?cat=5");
?>
</body>
</html>