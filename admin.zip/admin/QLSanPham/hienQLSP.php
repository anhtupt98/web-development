<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
	<?php
		include("../KetNoi/ketnoi.inc");
		$end=7;
		if(isset($_GET["trang"]))
		{
			$trang1=$_GET["trang"];
			settype($trang1,'int');
		}
		else
		{
			$trang1='';
		}
		if($trang1=='' || $trang1==1)
		{
			$start=0;
		}
		else
		{
			$start=ceil($trang1*$end)-$end;
		}
		$strSelect = "select tblquanlysp.MaSP,tblquanlysp.TenSP,tblquanlysp.mota,tblquanlysp.anh,tblquanlysp.gia,tblquanlysp.tinhtrang,tblquanlynsx.TenNSX from tblquanlysp inner join tblquanlynsx on tblquanlysp.MaNSX=tblquanlynsx.MaNSX order by tblquanlysp.MaSP desc LIMIT $start,$end"; 
		$resultABC = mysqli_query($con,$strSelect);
		$dem=0;
	
		if(isset($_GET['TenSPTimKiem']))
		{
			$tensptimkiem=$_GET['TenSPTimKiem'];
			$sql="select tblquanlysp.MaSP,tblquanlysp.TenSP,tblquanlysp.mota,tblquanlysp.anh,tblquanlysp.gia,tblquanlysp.tinhtrang,tblquanlynsx.TenNSX from tblquanlysp inner join tblquanlynsx on tblquanlysp.MaNSX=tblquanlynsx.MaNSX where tblquanlysp.TenSP like '%$tensptimkiem%' LIMIT $start,$end";
			$resultABC=mysqli_query($con,$sql);
		}
		
		if(isset($_GET['GiaTimKiem']))
		{
			$giatimkiem=$_GET['GiaTimKiem'];
			$sql="select tblquanlysp.MaSP,tblquanlysp.TenSP,tblquanlysp.mota,tblquanlysp.anh,tblquanlysp.gia,tblquanlysp.tinhtrang,tblquanlynsx.TenNSX from tblquanlysp inner join tblquanlynsx on tblquanlysp.MaNSX=tblquanlynsx.MaNSX where tblquanlysp.gia like '%$giatimkiem%' LIMIT $start,$end";
			$resultABC=mysqli_query($con,$sql);
		}
		if(isset($_GET['TinhTrang']))
		{
			$tinhtrangtimkiem=$_GET['TinhTrang'];
			$sql="select tblquanlysp.MaSP,tblquanlysp.TenSP,tblquanlysp.mota,tblquanlysp.anh,tblquanlysp.gia,tblquanlysp.tinhtrang,tblquanlynsx.TenNSX from tblquanlysp inner join tblquanlynsx on tblquanlysp.MaNSX=tblquanlynsx.MaNSX where tblquanlysp.tinhtrang like '%$tinhtrangtimkiem%' LIMIT $start,$end";
			$resultABC=mysqli_query($con,$sql);
		}
	?>
    
   
	<div class="danhsachsanpham">
 	
    <table border="1" align="center" style="position:absolute;top:0px" width="100%" cellspacing="0px" height="600px" bordercolor="#000000">
    	<tr valign="top">
           	<td colspan="9"> <h1><font color="#666666" size="+5" >♛ Danh Sách Sản Phẩm</font></h1></td>
        </tr>
    	<tr>
        	<td>Mã sản phẩm</td>
            <td>Tên sản phẩm</td>
            <td>Mô tả</td>
            <td>Ảnh</td>
            <td>Giá</td>
            <td>Tình trạng</td>
            <td>Tên nhà sản xuất</td>
            <td></td>
            <td></td>
        </tr>
        <?php
			while($rowSP=mysqli_fetch_array($resultABC))
			{
		?>
        <tr>
        	<td><?php echo $rowSP["MaSP"];?></td>
            <td><?php echo $rowSP["TenSP"];?></td>
            <td><?php echo $rowSP["mota"];?></td>
            <td><img src="../../img/<?php echo $rowSP["anh"];?>" style="width:50px;height:50px" /></td>
            <td><?php echo $rowSP["gia"];?></td>
            <td><?php echo $rowSP["tinhtrang"];?></td>
            <td><?php echo $rowSP["TenNSX"];?></td>
            <td><a href="../login/AdminThuong.php?cat=501&&MaSP=<?php echo $rowSP["MaSP"]; ?>"><img src="../../img/sua1.jpg" height="50" width="50" /></a></td>
            <td><a href="../login/AdminThuong.php?cat=502&&MaSP=<?php echo $rowSP["MaSP"]; ?>" onclick="return confirm('Bạn có muốn xóa');"><img src="../../img/xoabo.gif" height="40" width="40" /></a></td>
        </tr>
          <?php
				$dem++;
		?>
        <?php 
			}
        ?>
    </table>
    </div>
        <div class="phantrang">
			<?php
           $strSelect = "select tblquanlysp.MaSP,tblquanlysp.TenSP,tblquanlysp.mota,tblquanlysp.anh,tblquanlysp.gia,tblquanlysp.tinhtrang,tblquanlynsx.TenNSX from tblquanlysp inner join tblquanlynsx on tblquanlysp.MaNSX=tblquanlynsx.MaNSX order by tblquanlysp.MaSP desc"; 
		$resultABC = mysqli_query($con,$strSelect);
		if(isset($_GET['TenSPTimKiem']))
		{
			$tensptimkiem=$_GET['TenSPTimKiem'];
			$sql="select tblquanlysp.MaSP,tblquanlysp.TenSP,tblquanlysp.mota,tblquanlysp.anh,tblquanlysp.gia,tblquanlysp.tinhtrang,tblquanlynsx.TenNSX from tblquanlysp inner join tblquanlynsx on tblquanlysp.MaNSX=tblquanlynsx.MaNSX where tblquanlysp.TenSP like '%$tensptimkiem%'";
			$resultABC=mysqli_query($con,$sql);
		}
		if(isset($_GET['GiaTimKiem']))
		{
			$giatimkiem=$_GET['GiaTimKiem'];
			$sql="select tblquanlysp.MaSP,tblquanlysp.TenSP,tblquanlysp.mota,tblquanlysp.anh,tblquanlysp.gia,tblquanlysp.tinhtrang,tblquanlynsx.TenNSX from tblquanlysp inner join tblquanlynsx on tblquanlysp.MaNSX=tblquanlynsx.MaNSX where tblquanlysp.gia like '%$giatimkiem%'";
			$resultABC=mysqli_query($con,$sql);
		}
		if(isset($_GET['TinhTrang']))
		{
			$tinhtrangtimkiem=$_GET['TinhTrang'];
			$sql="select tblquanlysp.MaSP,tblquanlysp.TenSP,tblquanlysp.mota,tblquanlysp.anh,tblquanlysp.gia,tblquanlysp.tinhtrang,tblquanlynsx.TenNSX from tblquanlysp inner join tblquanlynsx on tblquanlysp.MaNSX=tblquanlynsx.MaNSX where tblquanlysp.tinhtrang like '%$tinhtrangtimkiem%'";
			$resultABC=mysqli_query($con,$sql);
		}
			$dem=ceil(mysqli_num_rows($resultABC));
			$a=ceil($dem/$end);
			for($b=1;$b<=$a;$b++)	
				{
					echo '<a href="AdminThuong.php?cat=5&&trang='.$b.'">'.' '.$b.' '.'</a>';
				}

            ?>

    </div>
    <?php
		include("../KetNoi/dongketnoi.inc");
	?>
   	<div class="TenSPTimKiem" style="position:absolute;top:83px;left:120px">
   <form method="get" action="../QlSanPham/TenSPTimKiem.php">
   <table>
   		<tr>
        	<td><input type="text" name="TenSPTimKiem" placeholder="Nhập tên sản phẩm"/></td>
            <td><input type="submit" value="Tìm Kiếm"/></td>
        </tr>
   </table>
   </form>
   <div class="GiaTimKiem" style="position:absolute;top:0px;left:350px">
   <form method="get" action="../QlSanPham/GiaTimKiem.php">
   <table>
   		<tr>
        	<td><input type="text" name="GiaTimKiem" placeholder="Nhập giá sản phẩm"/></td>
            <td><input type="submit" value="Tìm Kiếm"/></td>
        </tr>
   </table>
   </form>
   <div class="timkiemTinhTrang" style="position:absolute;top:3px;left:400px">
  <form action="../QlSanPham/TinhTrangTimKiem.php" method="get">
<table>
        <tr>
            <td><input type="hidden" name="xem" value="lichsudonhang" />	</td>
    		<center>
            <select name="TinhTrang">
            <option value="-1">---Chọn---</option>
            <option value="Còn hàng">Còn hàng</option>
            <option value="Hết hàng">Hết hàng</option>
            </select>
        	<input type="submit" id="timkiem2" name="btnTimKiem" value="Tìm Kiếm" style="position:absolute;top:0px;left:90px"/>
            </center>
        </tr>
</table>
</form>
    </div>
   
</body>
</html>
