<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<script>
function ktsuasp()
{
	var dem=0;
	var tensp=document.getElementById("txtTenSP").value;
	var errTensp=document.getElementById("errTensp");
	if(tensp.length==0)
	{
		errTensp.innerHTML=" *Không được để trống";
	}
	else
	{
		errTensp.innerHTML="";
		dem++;
	}
	var mota=document.getElementById("txtMota").value;
	var errMota=document.getElementById("errMota");
	if(mota.length==0)
	{
		errMota.innerHTML=" *Không được để trống";
	}
	else
	{
		errMota.innerHTML="";
		dem++;
	}
	var gia=document.getElementById("txtGia").value;
	var errGia=document.getElementById("errGia");
	if(gia.length==0)
	{
		errGia.innerHTML=" *Không được để trống";
	}
	else
	{
		errGia.innerHTML="";
		dem++;
	}
	var tinhtrang=document.getElementById("cboTT").value;
	var errTinhTrang=document.getElementById("errTinhTrang");
	if(tinhtrang==0)
	{
		errTinhTrang.innerHTML=" *Phải chọn tình trạng";
	}
	else
	{
		errTinhTrang.innerHTML="";
		dem++;
	}
	if(dem==4)
	{
		return true;
	}
	else
	{
		return false;
	}
}
</script>
<body>
	<?php 
		$MaSP = $_GET["MaSP"];
		include("../KetNoi/ketnoi.inc");
		$strSelect = "select * from tblquanlysp where MaSP=$MaSP";
		$resultABC = mysqli_query($con,$strSelect);
		$rowSP=mysqli_fetch_array($resultABC);
	?>
   	<form action="../QLSanPham/suaQLSPxuly.php" method="post" enctype="multipart/form-data">
    	<table border="1" cellspacing="0" bordercolor="#000000" style="position:absolute;top:110px;left:250px" width="60%">
        	<tr >
            		<h1><font color="#666666" size="+5">♛ Quản Lý Sản Phẩm(Sửa Sản Phẩm)</font></h1>
       		 </tr>
            <tr>
            	<td>Mã Sản phẩm</td>
                <td><input type="text" name="txtMaSP" value="<?php echo $rowSP["MaSP"]; ?>" readonly="readonly" /></td>
            </tr>
            <tr>
            	<td>Tên Sản phẩm</td>
                <td><input type="text" name="txtTenSP" value="<?php echo $rowSP["TenSP"]; ?>" id="txtTenSP"/><span id="errTensp"></span></td>
            </tr>
            <tr>
            	<td>Mô tả</td>
                <td><input type="text" name="txtMota" value="<?php echo $rowSP["mota"]; ?>" id="txtMota"/><span id="errMota"></span></td>
            </tr>
            <tr>
            	<td>Ảnh</td>
                <td><input type="file" name="imgUpload" /><img src="../../img/<?php echo $rowSP["anh"]; ?>" /></td>
            </tr>
            <tr>
            	<td>Giá</td>
                <td><input type="text" name="txtGia" value="<?php echo $rowSP["gia"]; ?>" id="txtGia"/><span id="errGia"></span></td>
            </tr>
            <tr>
            	<td>Tình Trạng</td>
                <td><select name="cboTT" id="cboTT">
                	<option value="0">--Chọn--</option>
                    <option value="Còn hàng">Còn Hàng</option>
                    <option value="Hếtt hàng">Hết Hàng</option>
                	</select>
                    <span id="errTinhTrang"></span>
                </td>
            </tr>
             <tr>
			<?php
                $result=mysqli_query($con,"select * from tblquanlynsx");
            ?>
                <td>Tên nhà sản xuất</td>
               
                <td>
                <select name="txtMaNSX">
                <?php
                while($row=mysqli_fetch_array($result))
                {
                ?>
                    <option value="<?php echo $row["MaNSX"];?>"><?php echo $row["TenNSX"];?></option>
                <?php
                }
                ?>
                </select>
                </td>
               
        	</tr>
            <tr>
			<?php
            $result2=mysqli_query($con,"select * from tblquanlyloaisp");
            ?>
                <td>Tên Loại</td>
                <td>
                <select name="txtMaLoai">
                <?php
                while($row2=mysqli_fetch_array($result2))
                {
                ?>
                    <option value="<?php echo $row2["MaLoai"];?>"><?php echo $row2["TenLoai"];?></option>
                <?php
                }
                ?>
                </select>
                
                </td>
        </tr>            <tr>
                <th colspan="2"><input type="submit" value="Sửa" onclick="return ktsuasp()"/></th>
            </tr>
        </table>
    </form>
    <?php
		include("../KetNoi/dongketnoi.inc");
	?>
</body>
</html>