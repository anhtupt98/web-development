<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
		$MaNSX=$_POST["txtMaNSX"];
		$TenNSX=$_POST["txtTenNSX"];
		include("../KetNoi/ketnoi.inc");
		$strInsert = "insert into tblquanlynsx (MaNSX,TenNSX) values ('$MaNSX','$TenNSX')";
		mysqli_query($con,$strInsert);
		include("../KetNoi/dongketnoi.php");
		header("Location:../login/AdminThuong.php?cat=3");
	?>
</body>
</html>