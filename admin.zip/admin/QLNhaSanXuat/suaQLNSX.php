<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<script>
function ktNSX()
{
	var TenNSX=document.getElementById("txtTenNSX").value;
	var errTenNSX=document.getElementById("errTenNSX");
	if(TenNSX.length==0)
	{
		errTenNSX.innerHTML=" *Không được để trống";
		return false;
	}
	else
	{
		errTenNSX.innerHTML="";
		return true;
	}
}
</script>

<body>
<?php 
	$MaNSX=$_GET["MaNSX"];
	include("../KetNoi/ketnoi.inc");
	$strSelect= "select * from tblquanlynsx where MaNSX=$MaNSX";
	$resultABC=mysqli_query($con,$strSelect);
	$row=mysqli_fetch_array($resultABC);
?>
	<form action="../QLNhaSanXuat/suaQLNSXXuLy.php" method="post">
    	<table border="1" cellspacing="0" bordercolor="#000000" style="position:absolute;top:100px;left:450px;" >
        	<tr >
            <h1><font color="#666666" size="+5">♛ Danh Sách Nhà Sản Xuất(Sửa)</font></h1>
        </tr>
        	<tr>
            	<td>Mã Nhà Sản Xuất</td>
                <td><input type="text" name="txtMaNSX" value="<?php echo $row["MaNSX"];  ?>" readonly="readonly"/></td>
            </tr>
            <tr>
            	<td>Tên Nhà Sản Xuất</td>
                <td><input type="text" name="txtTenNSX" value="<?php echo $row["TenNSX"]; ?>" id="txtTenNSX"/><span id="errTenNSX"></span></td>
            </tr>
            <tr>
            	<th colspan="2"><input type="submit" value="Sửa" onclick="return ktNSX()"/></th>
            </tr>
        </table>     
    </form>
<?php	
	include("../KetNoi/dongketnoi.inc");
?>
</body>
</html>