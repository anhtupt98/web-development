
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
	<?php 
		include("../KetNoi/ketnoi.inc");
		$strSelect = " select * from tblquanlynsx";
		$resultABC = mysqli_query($con,$strSelect);
	
		if(isset($_GET["TimKiemNSX"]))
		{
		$NhaSanXuatTimKiem=$_GET["TimKiemNSX"];
		$sql="select * from tblquanlyNSX where TenNSX like '%$NhaSanXuatTimKiem%' group by MaNSX order by MaNSX desc";
		$resultABC=mysqli_query($con,$sql);
		}
	?>
  <table border="1" align="center" cellspacing="0" style="position:absolute;left:250px;top:110px;width:60%;border-color:#000">
  		<tr >
            <h1><font color="#666666" size="+5">♛ Danh Sách Nhà Sản Xuất</font></h1>
        </tr>
  		<tr align="center">
        	<td>Mã Nhà Sản Xuất</td>
            <td>Tên Nhà Sản Xuất</td>
            <td></td>
            <td></td>
        </tr>
     <?php 
	 	while( $row = mysqli_fetch_array($resultABC))
		{
	 ?>
        <tr  align="center">
        	<td ><?php echo $row["MaNSX"]; ?></td>
            <td><?php echo $row["TenNSX"]; ?></td>
            <td><a href="../login/AdminThuong.php?cat=301&&MaNSX=<?php echo $row["MaNSX"];?>"><img src="../../img/sua1.jpg" height="50" width="50" /></a></td>
            <td><a href="../login/AdminThuong.php?cat=302&&MaNSX=<?php echo $row["MaNSX"];?>" onclick="return confirm 'Bạn có muốn xóa'"><img src="../../img/xoabo.gif" height="40" width="40" /></a></td>
        </tr>
      <?php 
		}
	  ?>
  </table>
   <div class="timkiemNSX" style="position:absolute;top:70px;right:450px">
  <form action="../QLNhaSanXuat/TimKiemNhaSanXuat.php" method="get" >
    	<table width="100px" align="right">
        	<tr>
            	<td><input type="hidden" name="xem" value="lichsudonhang" />	</td>
            	<td><input type="text" name="TimKiemNSX" placeholder="Nhập Tên Nhà Sản Xuất"  /></td>
            	<td><input type="submit" name="btnTimKiem" value="Tìm Kiếm"  /></td>
                
            </tr>
        </table>
   </form>
   </div>
    <?php 
		include("../KetNoi/dongketnoi.inc");
	?>
</body>
</html>
