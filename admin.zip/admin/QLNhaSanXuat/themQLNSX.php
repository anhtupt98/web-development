<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<script>
function ktNSX()
{
	var TenNSX=document.getElementById("txtTenNSX").value;
	var errTenNSX=document.getElementById("errTenNSX");
	if(TenNSX.length==0)
	{
		errTenNSX.innerHTML=" *Không được để trống";
		return false;
	}
	else
	{
		errTenNSX.innerHTML="";
		return true;
	}
}
</script>

<body>
<?php
include("../KetNoi/ketnoi.inc");
$strSelectMaxMa="select max(MaNSX) as MaxMa from tblquanlynsx";
$resultMaxMa=mysqli_query($con,$strSelectMaxMa);
$rowMaxMa=mysqli_fetch_array($resultMaxMa);
$MaxMa=$rowMaxMa["MaxMa"];
$MaNSX=1;
if($MaxMa!="")
{
	$MaNSX=$MaxMa+1;
}
?>
<form action="../QLNhaSanXuat/themQLNSXXuLy.php" method="post">
	<table border="1" cellspacing="0" align="center" style="position:absolute;left:350px;top:120px;border-color:#000;width:40%">
    	<tr >
            <h1><font color="#666666" size="+5">♛ Thêm Nhà Sản Xuất </font></h1>
        </tr>
        <tr>
        	<td align="center">Mã Nhà Sản Xuất:</td>
            <td><input type="text" name="txtMaNSX" size="35" id="txtMaNSX" value="<?php echo $MaNSX;?>" readonly="readonly"/></td>
        </tr>
        <tr>
        	<td align="center">Tên Nhà Sản Xuất:</td> 
            <td><input type="text" name="txtTenNSX" size="35" id="txtTenNSX"/><span id="errTenNSX"></span></td>
        </tr>
         <tr>
            <th colspan="2"><input type="submit" value="Thêm Mới" onclick="return ktNSX()"/></th>
        </tr>
    </table>
</form>
<?php
include("../KetNoi/dongketnoi.inc");
?>
</body>
</html>