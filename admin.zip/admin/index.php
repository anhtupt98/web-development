<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<style>
	#tong{width:100%;height:1100px}
	#header{width:100%;height:360px}
	#top{width:101.22%;height:40px;background:#333;}
	#banner{width:101.22%;height:270px;background:url(../img/banneradmin2.jpg)}
	.menu{width:101.22%;height:50px;background:#333;display: inline-block}
	#main{width:100%;height:740px;background:#999;margin:auto;position:absolute;top:368px}
	#hinhanh{width:90%;height:640px; background:#FFF;position:relative;left:65px;top:40px}
	a{text-decoration:none;}
	a:hover{color:#0F0}
	.drop1{background-color: #1B1B1B;color: white;padding: 16px;font-size: 16px;border: none;cursor: pointer;}
	.menu1 {position: relative;display: inline-block;}
	.dropdown1 {display: none;position: absolute; background-color: #f9f9f9;min-width: 160p;z-index: 1;}
	.dropdown1 a {color: black;padding: 12px 16px;text-decoration: none;display: block;}
	.dropdown1 a:hover {background-color: #f1f1f1}
	.menu1:hover .dropdown1 {display: block;}
	.menu1:hover .drop1 {background-color: #3e8e41;}
	.drop2{background-color: #1B1B1B;color: white;padding: 16px;font-size: 16px;border: none;cursor: pointer;}
	.menu2 {position: relative;display: inline-block;}
	.dropdown2 {display: none;position: absolute; background-color: #f9f9f9;min-width: 10px;z-index: 1;}
	.dropdown2 a {color: black;padding: 12px 16px;text-decoration: none;display: block;}
	.dropdown2 a:hover {background-color: #f1f1f1}
	.menu2:hover .dropdown2 {display: block;}
	.menu2:hover .drop2 {background-color: #3e8e41;}
	.drop3{background-color: #1B1B1B;color: white;padding: 16px;font-size: 16px;border: none;cursor: pointer;}
	.menu3 {position: relative;display: inline-block;}
	.dropdown3 {display: none;position: absolute; background-color: #f9f9f9;min-width: 160p;z-index: 1;}
	.dropdown3 a {color: black;padding: 12px 16px;text-decoration: none;display: block;}
	.dropdown3 a:hover {background-color: #f1f1f1}
	.menu3:hover .dropdown3 {display: block;}
	.menu3:hover .drop3 {background-color: #3e8e41;}
	.drop4{background-color: #1B1B1B;color: white;padding: 16px;font-size: 16px;border: none;cursor: pointer;}
	.menu4 {position: relative;display: inline-block;}
	.dropdown4 {display: none;position: absolute; background-color: #f9f9f9;min-width: 160p;z-index: 1;}
	.dropdown4 a {color: black;padding: 12px 16px;text-decoration: none;display: block;}
	.dropdown4 a:hover {background-color: #f1f1f1}
	.menu4:hover .dropdown4 {display: block;}
	.menu4:hover .drop4 {background-color: #3e8e41;}
	.drop5{background-color: #1B1B1B;color: white;padding: 16px;font-size: 16px;border: none;cursor: pointer;}
	.menu5 {position: relative;display: inline-block;}
	.dropdown5 {display: none;position: absolute; background-color: #f9f9f9;min-width: 160p;z-index: 1;}
	.dropdown5 a {color: black;padding: 12px 16px;text-decoration: none;display: block;}
	.dropdown5 a:hover {background-color: #f1f1f1}
	.menu5:hover .dropdown5 {display: block;}
	.menu5:hover .drop5 {background-color: #3e8e41;}
	
	 danhsachsanpham ul{width:100%;list-style:none;}
	.danhsachsanpham ul li{width:120px;height:auto;text-align:center;float:left;margin-left:30px;}
	.danhsachsanpham ul li a{text-decoration:none;}
	
	.phantrang{text-align:center;width:770px;height:20px;border:1px solid #FFF;overflow: auto;position:absolute;left:200px;bottom:0px;}
	
</style>

<body>
	<div id="tong">
    	<div id="header">
        	<div id="top">
            		
            </div>
        	<div id="banner"></div>
            <div class="menu">
            		
            </div>	
        </div>
     <div id="main">
                <div id="hinhanh">
                	<?php
						include("login/login.php");
						
					?>
                </div>
       </div>
     
    </div>

</body>
</html>
