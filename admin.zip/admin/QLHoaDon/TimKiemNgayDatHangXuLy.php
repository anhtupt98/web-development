<?php
	include("../KetNoi/ketnoi.inc"); 
		if(isset($_GET["NgayDatHang"]))
		{
			$NgayDatHangTimKiem=$_GET["NgayDatHang"];
			$sql="select A.MaHD,tblquanlythongtinkhachhang.TenKH,tblquanlythongtinkhachhang.sdt,A.ngaydathang,A.tinhtrang from (select tblquanlydonhang.MaHD,tblquanlydonhang.MaKH,tblquanlydonhang.ngaydathang,tblquanlydonhang.tinhtrang from tblquanlydonhang inner join tblquanlyhoadonchitiet on tblquanlydonhang.MaHD=tblquanlyhoadonchitiet.MaHD)A inner join tblquanlythongtinkhachhang on A.MaKH =tblquanlythongtinkhachhang.MaKH where A.ngaydathang like '%$NgayDatHangTimKiem%' group by A.MaHD  ";
			$result=mysqli_query($con,$sql);
			}
	include("../KetNoi/dongketnoi.inc"); 
	header("Location:../login/AdminThuong.php?cat=7&&NgayDatHang=$NgayDatHangTimKiem");
?>