<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php 
		include("../KetNoi/ketnoi.inc");
		$end=10;
		if(isset($_GET["trang"]))
		{
			$trang1=$_GET["trang"];
		}
		else
		{
			$trang1='';
		}
		if($trang1=='' || $trang1==1)
		{
			$start=0;
		}
		else
		{
			$start=($trang1*$end)-$end;
		}
		$strSelect = "select tblquanlydonhang.MaHD,tblquanlythongtinkhachhang.TenKH,tblquanlythongtinkhachhang.sdt,tblquanlydonhang.ngaydathang,tblquanlydonhang.tinhtrang from tblquanlydonhang inner join tblquanlythongtinkhachhang on tblquanlydonhang.MaKH=tblquanlythongtinkhachhang.MaKH order by tblquanlydonhang.MaHD desc limit $start,$end";
		$result= mysqli_query($con,$strSelect);
?>
<?php
		if(isset($_GET["TimKiem"]))
		{
			$MaHDTimKiem=$_GET["TimKiem"];
			$sql="select A.MaHD,tblquanlythongtinkhachhang.TenKH,tblquanlythongtinkhachhang.sdt,A.ngaydathang,A.tinhtrang from (select tblquanlydonhang.MaHD,tblquanlydonhang.MaKH,tblquanlydonhang.ngaydathang,tblquanlydonhang.tinhtrang from tblquanlydonhang inner join tblquanlyhoadonchitiet on tblquanlyhoadonchitiet.MaHD=tblquanlydonhang.MaHD)A inner join tblquanlythongtinkhachhang on A.MaKH = tblquanlythongtinkhachhang.MaKH where A.MaHD like '%$MaHDTimKiem%' group by A.MaHD order by A.MaHD desc limit $start,$end";
			$result=mysqli_query($con,$sql);
		}
	if(isset($_GET["NgayDatHang"]))
		{
			$NgayDatHangTimKiem=$_GET["NgayDatHang"];
			$sql="select A.MaHD,tblquanlythongtinkhachhang.TenKH,tblquanlythongtinkhachhang.sdt,A.ngaydathang,A.tinhtrang from (select tblquanlydonhang.MaHD,tblquanlydonhang.MaKH,tblquanlydonhang.ngaydathang,tblquanlydonhang.tinhtrang from tblquanlydonhang inner join tblquanlyhoadonchitiet on tblquanlydonhang.MaHD=tblquanlyhoadonchitiet.MaHD)A inner join tblquanlythongtinkhachhang on A.MaKH =tblquanlythongtinkhachhang.MaKH where A.ngaydathang like '%$NgayDatHangTimKiem%' group by A.MaHD order by A.MaHD desc limit $start,$end";
			$result=mysqli_query($con,$sql);
			}
		if(isset($_GET["TenKhachHang"]))
			{
			$TenKhachHangTimKiem=$_GET["TenKhachHang"];
			$sql="select A.MaHD,tblquanlythongtinkhachhang.TenKH,tblquanlythongtinkhachhang.sdt,A.ngaydathang,A.tinhtrang from (select tblquanlydonhang.MaHD,tblquanlydonhang.MaKH,tblquanlydonhang.ngaydathang,tblquanlydonhang.tinhtrang from tblquanlydonhang inner join tblquanlyhoadonchitiet on tblquanlydonhang.MaHD=tblquanlyhoadonchitiet.MaHD)A inner join tblquanlythongtinkhachhang on A.MaKH =tblquanlythongtinkhachhang.MaKH where tblquanlythongtinkhachhang.TenKH like '%$TenKhachHangTimKiem%' group by A.MaHD order by A.MaHD desc limit $start,$end";
			$result=mysqli_query($con,$sql);
			}
			if(isset($_GET["TinhTrang"]))
			{
			$TinhTrangTimKiem=$_GET["TinhTrang"];
			$sql="select A.MaHD,tblquanlythongtinkhachhang.TenKH,tblquanlythongtinkhachhang.sdt,A.ngaydathang,A.tinhtrang from (select tblquanlydonhang.MaHD,tblquanlydonhang.MaKH,tblquanlydonhang.ngaydathang,tblquanlydonhang.tinhtrang from tblquanlydonhang inner join tblquanlyhoadonchitiet on tblquanlydonhang.MaHD=tblquanlyhoadonchitiet.MaHD)A inner join tblquanlythongtinkhachhang on A.MaKH =tblquanlythongtinkhachhang.MaKH where A.tinhtrang like '%$TinhTrangTimKiem%' group by A.MaHD limit $start,$end";
			$result=mysqli_query($con,$sql);
		}
?>
	<table border="1" cellspacing="0" bordercolor="#000000" style="position:absolute;left:180px;top:130px" width="70%">
    	<tr >
            <h1><font color="#666666" size="+5">♛ Quản Lý Hóa Đơn</font></h1>
        </tr>
  		<tr>
        	<td>Mã Hóa Đơn</td>
            <td>Tên Khách Hàng</td>
            <td>Số điện thoại</td>
            <td>Ngày Đặt Hàng</td>
            <td>Tình Trạng</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
     <?php 
	 	while($row=mysqli_fetch_array($result))
		{
	 ?>
        <tr>
        	<td><?php echo $row["MaHD"]; ?></td>
            <td><?php echo $row["TenKH"]; ?></td>
            <td><?php echo $row["sdt"]; ?></td>
            <td><?php echo $row["ngaydathang"]; ?></td>
            <td><?php echo $row["tinhtrang"]; ?></td>
            <td><a href="../QLHoaDon/thaydoitrangthai.php?MaHD=<?php echo $row["MaHD"];  ?>"><img src="../../img/thaydoitinhtrang.svg" height="40" width="40" /></a></td>
            <td><a href="../login/AdminThuong.php?cat=701&&MaHD=<?php echo $row["MaHD"];  ?>"><img src="../../img/xemchitiet.jpg" height="30" width="100" /></a></td>
            <td><a href="../login/AdminThuong.php?cat=702&&MaHD=<?php echo $row["MaHD"];  ?>" onclick="return confirm"><img src="../../img/xoabo.gif" height="40" width="40" /></a></td>
        </tr>
      <?php 
		}
	  ?>
	 </table>
     <div class="phantrang">
			<?php
            $sqltrang="select tblquanlydonhang.MaHD,tblquanlythongtinkhachhang.TenKH,tblquanlythongtinkhachhang.sdt from tblquanlydonhang inner join tblquanlythongtinkhachhang on tblquanlydonhang.MaKH=tblquanlythongtinkhachhang.MaKH order by tblquanlydonhang.MaHD desc";
			$result=mysqli_query($con,$sqltrang);
			if(isset($_GET["TimKiem"]))
		{
			$MaHDTimKiem=$_GET["TimKiem"];
			$sql="select A.MaHD,tblquanlythongtinkhachhang.TenKH,tblquanlythongtinkhachhang.sdt,A.ngaydathang,A.tinhtrang from (select tblquanlydonhang.MaHD,tblquanlydonhang.MaKH,tblquanlydonhang.ngaydathang,tblquanlydonhang.tinhtrang from tblquanlydonhang inner join tblquanlyhoadonchitiet on tblquanlyhoadonchitiet.MaHD=tblquanlydonhang.MaHD)A inner join tblquanlythongtinkhachhang on A.MaKH = tblquanlythongtinkhachhang.MaKH where A.MaHD like '%$MaHDTimKiem%' group by A.MaHD order by A.MaHD desc";
			$result=mysqli_query($con,$sql);
		}
	if(isset($_GET["NgayDatHang"]))
		{
			$NgayDatHangTimKiem=$_GET["NgayDatHang"];
			$sql="select A.MaHD,tblquanlythongtinkhachhang.TenKH,tblquanlythongtinkhachhang.sdt,A.ngaydathang,A.tinhtrang from (select tblquanlydonhang.MaHD,tblquanlydonhang.MaKH,tblquanlydonhang.ngaydathang,tblquanlydonhang.tinhtrang from tblquanlydonhang inner join tblquanlyhoadonchitiet on tblquanlydonhang.MaHD=tblquanlyhoadonchitiet.MaHD)A inner join tblquanlythongtinkhachhang on A.MaKH =tblquanlythongtinkhachhang.MaKH where A.ngaydathang like '%$NgayDatHangTimKiem%' group by A.MaHD order by A.MaHD desc";
			$result=mysqli_query($con,$sql);
			}
		if(isset($_GET["TenKhachHang"]))
			{
			$TenKhachHangTimKiem=$_GET["TenKhachHang"];
			$sql="select A.MaHD,tblquanlythongtinkhachhang.TenKH,tblquanlythongtinkhachhang.sdt,A.ngaydathang,A.tinhtrang from (select tblquanlydonhang.MaHD,tblquanlydonhang.MaKH,tblquanlydonhang.ngaydathang,tblquanlydonhang.tinhtrang from tblquanlydonhang inner join tblquanlyhoadonchitiet on tblquanlydonhang.MaHD=tblquanlyhoadonchitiet.MaHD)A inner join tblquanlythongtinkhachhang on A.MaKH =tblquanlythongtinkhachhang.MaKH where tblquanlythongtinkhachhang.TenKH like '%$TenKhachHangTimKiem%' group by A.MaHD order by A.MaHD desc";
			$result=mysqli_query($con,$sql);
			}
			if(isset($_GET["TinhTrang"]))
			{
			$TinhTrangTimKiem=$_GET["TinhTrang"];
			$sql="select A.MaHD,tblquanlythongtinkhachhang.TenKH,tblquanlythongtinkhachhang.sdt,A.ngaydathang,A.tinhtrang from (select tblquanlydonhang.MaHD,tblquanlydonhang.MaKH,tblquanlydonhang.ngaydathang,tblquanlydonhang.tinhtrang from tblquanlydonhang inner join tblquanlyhoadonchitiet on tblquanlydonhang.MaHD=tblquanlyhoadonchitiet.MaHD)A inner join tblquanlythongtinkhachhang on A.MaKH =tblquanlythongtinkhachhang.MaKH where A.tinhtrang like '%$TinhTrangTimKiem%' group by A.MaHD";
			$result=mysqli_query($con,$sql);
		}
			$dem=ceil(mysqli_num_rows($result));
			$a=ceil($dem/$end);
			for($b=1;$b<=$a;$b++)
				echo '<a href="?cat=7&&trang='.$b.'">'.' '.$b.' '.'</a>';
            ?>
        </div>
  <?php 
		include("../KetNoi/dongketnoi.inc");
	?>
    <div class="timkiemHD" style="position:absolute;top:80px;left:80px">
  <form action="../QLHoaDon/TimKiemMaHDXuLy.php" method="get" >
    	<table width="100px" align="right">
        	<tr>
            	<td><input type="text" name="TimKiem" placeholder="Nhập Mã Hóa Đơn"  /></td>
            	<td><input type="submit" name="btnTimKiem" value="Tìm Kiếm"  /></td>
                
            </tr>
        </table>
   </form>
   </div>
   <div class="timkiemTenKH" style="position:absolute ; left:380px;top:80px">
  <form action="../QLHoaDon/TimKiemTenKH.php" method="get" >
    	<table width="100px" align="right">
        	<tr>
            	<td><input type="text" name="TenKhachHang" placeholder="Nhập Tên Khách Hàng"  /></td>
            	<td><input type="submit" name="btnTimKiem" value="Tìm Kiếm"  /></td>
                
            </tr>
        </table>
   </form>
   </div>
    <div class="timkiemNDH" style="position:absolute ; right:305px;top:80px">
  <form action="../QLHoaDon/TimKiemNgayDatHangXuLy.php" method="get" >
    	<table width="100px" align="right" >
        	<tr>
            	<td><input type="date" name="NgayDatHang" placeholder="Nhập Ngày Đặt Hàng"  /></td>
            	<td><input type="submit" name="btnTimKiem" value="Tìm Kiếm"  /></td>
                
            </tr>
        </table>
   </form>
   </div>
   <div class="timkiemTinhTrang" style="position:absolute ; right:70px;top:85px">
  <form action="../QLHoaDon/TimKiemTinhTrangXuLy.php" method="get">
<table>
        <tr>
            <td><input type="hidden" name="xem" value="lichsudonhang" />	</td>
            <center><select name="TinhTrang">
            <option value="-1">---Chọn---</option>
            <option value="Vừa đặt hàng">Vừa đặt hàng</option>
            <option value="Đang giao hàng">Đang giao hàng</option>
            <option value="Đã giao hàng">Đã giao hàng</option>
            </select>
        	<input type="submit" id="timkiem2" name="btnTimKiem" value="Tìm Kiếm"/>
            </center>
        </tr>
</table>
</form>
    </div>
</body>
</html>
