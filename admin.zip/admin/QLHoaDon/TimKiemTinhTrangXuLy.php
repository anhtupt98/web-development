
<?php 
	include("../KetNoi/ketnoi.inc");
	if(isset($_GET["TinhTrang"]))
		{
			$TinhTrangTimKiem=$_GET["TinhTrang"];
			$sql="select A.MaHD,tblquanlythongtinkhachhang.TenKH,tblquanlythongtinkhachhang.sdt,A.ngaydathang,A.tinhtrang from (select tblquanlydonhang.MaHD,tblquanlydonhang.MaKH,tblquanlydonhang.ngaydathang,tblquanlydonhang.tinhtrang from tblquanlydonhang inner join tblquanlyhoadonchitiet on tblquanlydonhang.MaHD=tblquanlyhoadonchitiet.MaHD)A inner join tblquanlythongtinkhachhang on A.MaKH =tblquanlythongtinkhachhang.MaKH where A.tinhtrang like '%$TinhTrangTimKiem%' group by A.MaHD ";
			$resultABC=mysqli_query($con,$sql);
		}
	include("../KetNoi/dongketnoi.inc");
	header("Location:../login/AdminThuong.php?cat=7&&TinhTrang=$TinhTrangTimKiem");
?>