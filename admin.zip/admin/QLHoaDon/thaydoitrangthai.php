<?php
$MaHD=$_GET["MaHD"];
include("../KetNoi/ketnoi.inc");
$result=mysqli_query($con,"select * from tblquanlydonhang where MaHD='$MaHD'");
$row=mysqli_fetch_array($result);
if($row["tinhtrang"]=='Vừa đặt hàng')
{
	mysqli_query($con,"update tblquanlydonhang set tinhtrang='Đang giao hàng' where MaHD='$MaHD'");
}
if($row["tinhtrang"]=='Đang giao hàng')
{
	mysqli_query($con,"update tblquanlydonhang set tinhtrang='Đã giao hàng' where MaHD='$MaHD'");
}
include("../KetNoi/dongketnoi.inc");
header("Location:../login/AdminThuong.php?cat=7");
?>