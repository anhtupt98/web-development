<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
		$MaHD=$_GET["MaHD"]; 
		include("../KetNoi/ketnoi.inc");
		$strSelect = "select A.MaHD,A.MaSP,tblquanlysp.TenSP,A.soluong,A.ngaydathang,A.tinhtrang,tblquanlysp.gia from (select tblquanlyhoadonchitiet.MaHD,tblquanlydonhang.MaKH,tblquanlydonhang.ngaydathang,tblquanlydonhang.tinhtrang,tblquanlyhoadonchitiet.MaSP,tblquanlyhoadonchitiet.soluong from tblquanlydonhang inner join tblquanlyhoadonchitiet on tblquanlydonhang.MaHD = tblquanlyhoadonchitiet.MaHD)A inner join tblquanlysp on A.MaSP = tblquanlysp.MaSP where A.MaHD=$MaHD";
		$resultABC = mysqli_query($con,$strSelect);
		
?>

	<table border="1" cellspacing="0" bordercolor="#000000" style="position:absolute;left:250px;top:110px" width="60%">
    	<tr >
            <h1><font color="#666666" size="+5">♛ Quản Lý Hóa Đơn(Xem Chi Tiết)</font></h1>
        </tr>
  		<tr>
        	<td>Mã Hóa Đơn</td>
        	<td>Mã Sản Phẩm</td>
        	<td>Tên Sản Phẩm</td>
            <td>Số Lượng</td>
            <td>Thành Tiền</td>
            <td></td>
        </tr>
     <?php
	 	$Tongtien=0; 
	 	while( $row = mysqli_fetch_array($resultABC))
		{
			
	 ?>
        <tr>
        	<td><?php echo $row["MaHD"];?></td>
        	<td><?php echo $row["MaSP"];?></td>
        	<td><?php echo $row["TenSP"]; ?></td>
            <td><input type="text" value="<?php echo $row["soluong"]; ?>" /></td>
            <td><?php echo $row["soluong"]*$row["gia"];?></td>
            <td><a href="../login/AdminThuong.php?cat=703&&MaHD=<?php echo $row["MaHD"];  ?>&&MaSP=<?php echo $row["MaSP"];  ?>"><img src="../../img/sua1.jpg" height="50" width="50" /></a></td>
        </tr>
      <?php
	  		$Tongtien+=$row["soluong"]*$row["gia"];
		}
	  ?> 
      		<tr>
        		<td colspan="8"> Tổng Tiền: <?php echo $Tongtien. "VNĐ";?></td>
      		</tr>
	 </table>

      
  <?php 
		include("../KetNoi/dongketnoi.inc");
	?>
</body>
</html>