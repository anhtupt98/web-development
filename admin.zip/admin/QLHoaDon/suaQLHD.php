<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<script>
function ktHD()
{
	var dem=0;
	var Soluong=document.getElementById("txtSoluong").value;
	var errSoluong=document.getElementById("errSoluong");
	if(Soluong.length==0)
	{
		errSoluong.innerHTML=" *Không được để trống";
	}
	else if(isNaN(Soluong)==true)
	{
		errSoluong.innerHTML=" *Bạn phải nhập số";
	}
	else
	{
		errSoluong.innerHTML="";
		dem++;
	}
	if(dem==1)
	{
		return true;
	}
	else
	{
		return false;
	}
}
</script>

<body>
<?php
	$MaHD=$_GET["MaHD"];
	$MaSP=$_GET["MaSP"];
	include("../KetNoi/ketnoi.inc");
	$strSelect= "select * from tblquanlydonhang where MaHD=$MaHD";
	$resultABC=mysqli_query($con,$strSelect);
	$row=mysqli_fetch_array($resultABC);
	$strSelectA = "select MaSP,soluong from tblquanlyhoadonchitiet where MaHD=$MaHD";
	$resultABCD=mysqli_query($con,$strSelectA);

?>
	<form action="../QLHoaDon/suaQLHDXuLy.php" method="post">
    	<table border="1" style="position:absolute;left:450px;top:100px">
        <?php
			while(	$rowA=mysqli_fetch_array($resultABCD))
			{
		?>
        	<tr>
            	<td>Mã Hóa Đơn</td>
                <td><input type="text" name="txtMaHD" value="<?php echo $row["MaHD"];  ?>" readonly="readonly"/></td>
            </tr>
            <tr>
            	<td>Mã Khách Hàng</td>
                <td><input type="text" name="txtMaKH" value="<?php echo $row["MaKH"]; ?>"  readonly="readonly"/></td>
            </tr>
            <tr>
            	<td>Mã Sản Phẩm</td>
                <td><input type="text" name="txtMaSP" value="<?php echo $rowA["MaSP"]; ?>"  readonly="readonly"/></td>
            </tr>
             <tr>
            	<td>Số lượng</td>
                <td><input type="text" name="txtSoluong" value="<?php echo $rowA["soluong"]; ?>" id="txtSoluong"/><span id="errSoluong"></span></td>
            </tr>
            <tr>
                <th colspan="2"><input type="submit" value="Sửa" onclick="return ktHD()"/></th>
            </tr>
            <?php
				}
			?>
        </table>
    </form>
<?php	
	include("../KetNoi/dongketnoi.inc");
?>
</body>
</html>