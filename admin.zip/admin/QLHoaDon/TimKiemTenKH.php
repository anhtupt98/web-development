<?php
	include("../KetNoi/ketnoi.inc"); 
		if(isset($_GET["TenKhachHang"]))
		{
			$TenKhachHangTimKiem=$_GET["TenKhachHang"];
			$sql="select A.MaHD,tblquanlythongtinkhachhang.TenKH,tblquanlythongtinkhachhang.sdt,A.ngaydathang,A.tinhtrang from (select tblquanlydonhang.MaHD,tblquanlydonhang.MaKH,tblquanlydonhang.ngaydathang,tblquanlydonhang.tinhtrang from tblquanlydonhang inner join tblquanlyhoadonchitiet on tblquanlydonhang.MaHD=tblquanlyhoadonchitiet.MaHD)A inner join tblquanlythongtinkhachhang on A.MaKH =tblquanlythongtinkhachhang.MaKH where tblquanlythongtinkhachhang.TenKH like '%$TenKhachHangTimKiem%' group by A.MaHD  ";
			$result=mysqli_query($con,$sql);
			}
	include("../KetNoi/dongketnoi.inc"); 
	header("Location:../login/AdminThuong.php?cat=7&&TenKhachHang=$TenKhachHangTimKiem");
?>