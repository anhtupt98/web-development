
<?php 
	include("../KetNoi/ketnoi.inc");
	if(isset($_GET["TimKiem"]))
		{
			$MaHDTimKiem=$_GET["TimKiem"];
			$sql="select * from tblquanlydonhang inner join tblquanlyhoadonchitiet on tblquanlydonhang.MaHD = tblquanlychitiet.MaHD where tblquanlydonhang.MaHD like '%$MaHDTimKiem%'";
			$resultABC=mysqli_query($con,$sql);
		}
	include("../KetNoi/dongketnoi.inc");
	header("Location:../login/AdminThuong.php?cat=7&&TimKiem=$MaHDTimKiem");
?>