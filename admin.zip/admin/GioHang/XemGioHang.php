<?php
	session_start();
	if(isset($_SESSION["GioHang"]))
	{
		$GioHang=$_SESSION["GioHang"];
?>
<form action="CapNhatGioHang.php" method="post">
	<table border="1">
    	<tr>
        	<td>Tên sản phẩm</td>
            <td>Ảnh</td>
            <td>Giá</td>
            <td>Số lượng</td>
            <td>Thành tiền</td>
            <td></td>
        </tr>
        <?php
		$TongTien=0;
		foreach($GioHang as $MaSP=>$SoLuong)
		{
			$ThanhTien=0;
			include("../KetNoi/ketnoi.inc");
			$strSelect="select * from tblquanlysp where MaSP=$MaSP";
			$result=mysqli_query($con,$strSelect);
			$row=mysqli_fetch_array($result);
			$ThanhTien=$row["gia"]*$SoLuong;
			$TongTien+=$ThanhTien;
		?>
        <tr>
        	<td><?php echo $row["TenSP"];?></td>
            <td><img src="../anh/<?php echo $row["anh"];?>" height="50px"></td>
            <td><?php echo $row["gia"];?></td>
            <td><input type="text" value="<?php echo $SoLuong;?>" name="arrSoLuong[]"></td>
            <td><?php echo $ThanhTien;?></td>
            <td><a href="XoaGioHang.php?MaSP=<?php echo $MaSP;?>" onClick="return confirm('Bạn có chắc muốn xóa');">Xóa</a></td>
        </tr>
        <?php
		include("../KetNoi/dongketnoi.inc");
		}
		?>
    </table>
    Tổng tiền:<?php echo $TongTien;?>
    <br>
    <input type="submit" value="Cập nhật giỏ hàng">
</form>
<a href="DatHang.php">Đặt hàng</a>
<?php
	}
	else
	{
		echo "Chưa có sản phẩm nào trong giỏ hàng";
	}
?>