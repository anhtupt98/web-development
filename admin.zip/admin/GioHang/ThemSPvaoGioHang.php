<?php
session_start();
if(isset($_GET["MaSP"]))
{
	$MaSP=$_GET["MaSP"];
	if(isset($_SESSION["GioHang"]))//Không phải lần đầu đặt hàng
	{
		if($_SESSION["GioHang"][$MaSP])//nếu đã tồn tại sản phẩm thì tăng số lượng lên 1
		{
			$_SESSION["GioHang"][$MaSP]++;
		}
		else//nếu chưa tồn tại sản phẩm
		{
			$_SESSION["GioHang"][$MaSP]=1;
		}
	}
	else //đặt hàng lần đầu
	{
		$_SESSION["GioHang"]=array();
		$_SESSION["GioHang"][$MaSP]=1;
	}
	header("Location:KhachHang.php");
}
else
{
	
}
?>