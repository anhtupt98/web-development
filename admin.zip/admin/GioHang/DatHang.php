<?php
session_start();
include("../KetNoi/ketnoi.inc");
//Lấy mã Hóa đơn
$strSelectMaxMa="select max(MaHD) as MaxMa from tblquanlydonhang";
$resultMaxMa=mysqli_query($con,$strSelectMaxMa);
$rowMaxMa=mysqli_fetch_array($resultMaxMa);
$MaxMa=$rowMaxMa["MaxMa"];

$MaHD=0;
if($MaxMa!="")
{
	$MaHD=$MaxMa+1;
}
echo($MaHD);
//Lấy Mã Khách Hàng
if(isset($_SESSION["User"]))
{
	$User=$_SESSION["User"];
	$strSelectKH="select tblquanlythongtinkhachhang.MaKH from tbltaikhoan inner join tblquanlythongtinkhachhang on tbltaikhoan.maTK=tblquanlythongtinkhachhang.maTK where tbltaikhoan.User='$User' ";
	
	$resultKH=mysqli_query($con,$strSelectKH);
	$rowKH=mysqli_fetch_array($resultKH);
	$MaKH=$rowKH["MaKH"];
	mysqli_query($con,"insert into tblquanlydonhang(MaHD,MaKH,ngaydathang,tinhtrang) values ($MaHD,$MaKH,now(),0)");
	
}
if(isset($_SESSION["GioHang"]))
{
	$GioHang=$_SESSION["GioHang"];
	foreach($GioHang as $MaSP=>$SoLuong)
	{
		mysqli_query($con,"insert into tblquanlyhoadonchitiet(MaHD,MaSP,soluong) values ($MaHD,$MaSP,$SoLuong)");
	}
	unset($_SESSION["GioHang"]);
	
}

?>