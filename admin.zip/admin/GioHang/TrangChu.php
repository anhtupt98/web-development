<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<a href="XemGioHang.php">Xem Giỏ Hàng</a>
<?php
	include("../KetNoi/ketnoi.inc");
	$strSelect="select * from tblquanlysp";
	$result=mysqli_query($con,$strSelect);
?>
<table>
	<tr>
    	
        	<?php
			$dem=0;
			while($row=mysqli_fetch_array($result))
			{
				$dem++;
			?>
         <td>
            <table>
            	<tr>
                	<td><img src="../anh/<?php echo $row["anh"];?>" height="100px"/></td>
                </tr>
                <tr>
                	<td><?php echo $row["TenSP"];?></td>
                </tr>
                <tr>
                	<td><?php echo $row["gia"];?></td>
                </tr>
                <tr>
                	<td><a href="ThemSPvaoGioHang.php?MaSP=<?php echo($row["MaSP"]);?>">Thêm vào giỏ hàng</a></td>
                </tr>
            </table>
        </td>
        <?php
			if($dem%3==0)
			{
		?>
    </tr>
    <tr>
    	<?php
			}
		}
		?>
    </tr>
</table>
<?php
	include("../KetNoi/dongketnoi.inc");
?>
</body>
</html>