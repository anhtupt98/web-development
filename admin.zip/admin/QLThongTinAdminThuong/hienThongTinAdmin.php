<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php 
	include("../KetNoi/ketnoi.inc");
	$strSelect = " select * from tblquanlythongtinadmin inner join tbltaikhoan on tblquanlythongtinadmin.MaAdmin=tbltaikhoan.maTK";
	$result = mysqli_query($con,$strSelect);
?>
	<table border="1">
    	<tr>
        	<td>Mã Admin</td>
            <td>Tên Admin</td>
            <td>Ngày Sinh</td>
            <td>Giới Tính</td>
            <td>Địa Chỉ</td>
            <td>User</td>
            <td>Pass</td>
            <td></td>
            <td></td>
        </tr>
      <?php
	  		while($row = mysqli_fetch_array($result))
			{
	   ?>  
        <tr>
        	<td><?php echo $row["MaAdmin"]; ?></td>
            <td><?php echo $row["ten"]; ?></td>
            <td><?php echo $row["ngaysinh"]; ?></td>
            <td><?php echo $row["gioitinh"]; ?></td>
            <td><?php echo $row["diachi"]; ?></td>
            <td><?php echo $row["User"]; ?></td>
            <td><?php echo $row["pass"]; ?></td>
            <td><a href="../QLThongTinAdmin/suaTTAdmin.php?MaAdmin=<?php echo $row["MaAdmin"]; ?>">Sửa</a></td>
            <td><a href="../QLThongTinAdmin/xoaTTAdmin.php?MaAdmin=<?php echo $row["MaAdmin"]; ?>" onclick="return confrim">Xóa</a></td>
        </tr>
        <?php
			}
	   ?>  
    </table>

<?php 
	include("../KetNoi/dongketnoi.inc");
?>
</body>
</html>