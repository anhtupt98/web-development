<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
	$MaAdmin = $_GET["MaAdmin"];
	include("../KetNoi/ketnoi.inc");
	$strSelect = " Select * from tblquanlythongtinadmin where MaAdmin='$MaAdmin'";
	$result = mysqli_query($con,$strSelect);
	$row = mysqli_fetch_array($result);
	$strSelectA = " Select * from tbltaikhoan where maTK='$MaAdmin'";
	$resultA = mysqli_query($con,$strSelectA);
	$rowA = mysqli_fetch_array($resultA);
 ?>
 	<form method="post" action="../QLThongTinAdmin/suaTTAdminXuLy.php">
    	Mã Admin:<input type="text" name="txtMaAdmin" value="<?php echo $row["MaAdmin"]; ?>"  /> </br>
        Tên Admin:<input type="text" name="txtTen" value="<?php echo $row["ten"]; ?>"  /> </br>
        Ngày Sinh:<input type="date" name="txtngaysinh" value="<?php echo $row["ngaysinh"]; ?>" /> </br>
        Giới Tính:
        <select name="cboGT">
                <option value="0">Chọn</option>
                <option value="Nam">Nam</option>
                <option value="Nữ">Nữ</option>
                
  `  	</select></br>
        Địa Chỉ:<input type="text" name="txtdiachi" value="<?php echo $row["diachi"]; ?>"  /> </br>
        User:<input type="text" name="txtUser" value="<?php echo $rowA["User"];?>" readonly="readonly"/>
        Pass:<input type="text" name="txtPass" value="<?php echo $rowA["pass"];?>" readonly="readonly"/>
        <input type="submit" value="Nhập Mới" />
    </form>
 <?php
	include("../KetNoi/dongketnoi.inc");
 ?>

</body>
</html>