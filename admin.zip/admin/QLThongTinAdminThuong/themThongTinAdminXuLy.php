<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php 

		$MaAdmin=$_POST["txtMaAdmin"];
		$ten = $_POST["txtTen"];
		$ngaysinh = $_POST["txtngaysinh"];
		$gioitinh = $_POST["cboGT"];
		$diachi = $_POST["txtdiachi"];
		$User=$_POST["txtUser"];
		$Pass=$_POST["txtPass"];
		include("../KetNoi/ketnoi.inc");
		$strInsert = "insert into tblquanlythongtinadmin (MaAdmin,ten,ngaysinh,gioitinh,diachi) values ('$MaAdmin','$ten','$ngaysinh','$gioitinh','$diachi')";
		mysqli_query($con,$strInsert);
		$strInsertA = "insert into tbltaikhoan (maTK,User,pass) values ('$MaAdmin','$User','$Pass')";
		mysqli_query($con,$strInsertA);
		include("../KetNoi/dongketnoi.inc");
		header("Location:hienTTAdmin.php");
?>
</body>
</html>