<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php 
	include("../KetNoi/ketnoi.inc");
	$strSelect = "select * from tblquanlythongtinkhachhang inner join tbltaikhoan on tblquanlythongtinkhachhang.maTK=tbltaikhoan.maTK";
	$result = mysqli_query($con,$strSelect);
	
	if(isset($_GET["TimKiemTenKH"]))
	{
		$TenKHTimKiem=$_GET["TimKiemTenKH"];
		$sql = "select * from tblquanlythongtinkhachhang inner join tbltaikhoan on tbltaikhoan.MaTK=tblquanlythongtinkhachhang.MaTK where tblquanlythongtinkhachhang.TenKH like '%$TenKHTimKiem%' group by tblquanlythongtinkhachhang.MaKH";
		$result=mysqli_query($con,$sql);
	}
	
	if(isset($_GET["TimKiemSDT"]))
	{
		$SDTTimKiem=$_GET["TimKiemSDT"];
		$sql = "select * from tblquanlythongtinkhachhang inner join tbltaikhoan on tbltaikhoan.MaTK=tblquanlythongtinkhachhang.MaTK where tblquanlythongtinkhachhang.sdt like '%$SDTTimKiem%' group by tblquanlythongtinkhachhang.MaKH ";
		$result=mysqli_query($con,$sql);
	}
?>
	<table border="1" cellspacing="0" bordercolor="#000000" style="position:absolute;left:180px;top:130px" >
    			<tr >
            			<h1><font color="#666666" size="+5">♛ Quản Lý Thông Tin Khách Hàng</font></h1>
        		</tr>
                <tr>
                    <td>Mã Khách Hàng</td>
                    <td>Tên Khách Hàng</td>
                    <td>Ngày Sinh</td>
                    <td>Giới Tính</td>
                    <td>Địa Chỉ</td>
                    <td>Số Điện Thoại</td>
                    <td>Mã Tài khoản</td>
                    <td>User</td>
                    <td>Pass</td>
                    <td></td>
                    <td></td>
                </tr>
        <?php
			while ($row= mysqli_fetch_array($result))
			{
		 ?>
                 <tr>
                    <td><?php echo $row["MaKH"]; ?></td>
                    <td><?php echo $row["TenKH"]; ?></td>
                    <td><?php echo $row["ngaysinh"]; ?></td>
                    <td><?php echo $row["gioitinh"]; ?></td>
                    <td><?php echo $row["diachi"]; ?></td>
                    <td><?php echo $row["sdt"]; ?></td>
                    <td><?php echo $row["maTK"]; ?></td>
                    <td><?php echo $row["User"]; ?></td>
                    <td><?php echo $row["pass"]; ?></td>
                    <td><a href="../login/AdminThuong.php?cat=801&&MaKH=<?php echo $row["MaKH"]; ?>"><img src="../../img/sua1.jpg" height="50" width="50" /></a></td>
                    <td><a href="../login/AdminThuong.php?cat=802&&MaKH=<?php echo $row["MaKH"]; ?>" onclick="return confrim"><img src="../../img/xoabo.gif" height="40" width="40" /></a></td>
                </tr>
         <?php 
		 	}
		 ?>
    </table>
        <div class="timkiemTenKH" style="position:absolute;left:340px;top:80px">
      <form action="../QLThongTinKhachHang/TimkiemTenKH.php" method="get" >
            <table width="100px" align="right">
                <tr>
                    <td><input type="hidden" name="xem" value="lichsudonhang" />	</td>
                    <td><input type="text" name="TimKiemTenKH" placeholder="Nhập Tên Khách Hàng"  /></td>
                    <td><input type="submit" name="btnTimKiem" value="Tìm Kiếm"  /></td>
                    
                </tr>
            </table>
       </form>
      	</div>
        <div class="timkiemSDT" style="position:absolute;right:320px;top:80px">
       <form action="../QLThongTinKhachHang/TimkiemSDT.php" method="get" >
    	<table width="100px" align="right">
        	<tr>
            	<td><input type="hidden" name="xem" value="lichsudonhang" />	</td>
            	<td><input type="text" name="TimKiemSDT" placeholder="Nhập SĐT Khách Hàng"  /></td>
            	<td><input type="submit" name="btnTimKiem" value="Tìm Kiếm"  /></td>
                
            </tr>
        </table>
        </form>
        </div>
   
<?php
	include("../KetNoi/dongketnoi.inc");
 ?>
</body>
</html>