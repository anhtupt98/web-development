<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<script>
function ktKH()
{
	var gt=Array();
	
}
</script>

<body>
<?php 
	$MaKH = $_GET["MaKH"];
	include("../KetNoi/ketnoi.inc");
	$strSelect = "select * from tblquanlythongtinkhachhang where MaKH=$MaKH";
	$result = mysqli_query($con,$strSelect);
	$row = mysqli_fetch_array($result);
?>
	<form action="../QLThongTinKhachHang/suaThongTinKhachHangXuLy.php" method="post">
        <table border="1" cellspacing="0" bordercolor="#000000" style="position:absolute;left:300px;top:100px" width="50%">
        	<tr >
            			<h1><font color="#666666" size="+5">♛ Quản Lý Thông Tin Khách Hàng(Sửa Thông Tin)</font></h1>
        		</tr>
        	<tr>
            	<td>Mã Khách Hàng:</td>
                <td><input type="text" name="txtMaKH" value="<?php echo $row["MaKH"]; ?>"  readonly="readonly"/></td>
            </tr>
            <tr>
            	<td>Tên Khách Hàng:</td>
                <td><input type="text" name="txtTenKH" value="<?php echo $row["TenKH"]; ?>"  readonly="readonly"/></td>
            </tr>
            <tr>
            	<td>Ngày Sinh:</td>
                <td><input type="date" name="txtngaysinh" value="<?php echo $row["ngaysinh"]; ?>"  /><span id="errNgaysinh"></span></td>
            </tr>
            <tr>
            	<td>Giới Tính:</td>
                <td><input type="radio" name="rdoGT" value="Nam" checked="checked" />Nam<input type="radio" name="rdoGT" value="Nữ"  />Nữ 
                <span id="errGT"></span></td>
            </tr>
            <tr>
            	<td>Địa Chỉ:</td>
                <td><input type="text" name="txtDiaChi" value="<?php echo $row["diachi"]; ?>"  /><span id="errDiaChi"></span></td>
            </tr>
            <tr>
            	<td>Số Điện Thoại:</td>
                <td><input type="text" name="txtSDT" value="<?php echo $row["sdt"]; ?>"  /><span id="errSDT"></span></td>
            </tr>
            <tr>
            	<td>Mã Tài Khoản:</td>
                <td><input type="text" name="txtmaTK" value="<?php echo $row["maTK"]; ?>"  readonly="readonly"/></td>
            </tr>
            <tr>
                <td colspan="2" align="center"><input type="submit" onclick="Thay Đổi Thông Tin"  value="Thay Đổi Thông Tin" /></td>
            </tr>
        </table>
    </form>
<?php
	include("../KetNoi/dongketnoi.inc");
?>
</body>
</html>